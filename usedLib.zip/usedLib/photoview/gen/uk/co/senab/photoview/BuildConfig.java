/** Automatically generated file. DO NOT MODIFY */
package uk.co.senab.photoview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}